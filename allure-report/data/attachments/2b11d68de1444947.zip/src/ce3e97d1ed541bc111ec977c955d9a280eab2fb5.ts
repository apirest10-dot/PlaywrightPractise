import test from "@playwright/test";
test.beforeEach(async({page})=>{
await page.goto('http://orangehrm.qedgetech.com/')
})
test.skip('Test Case Under Design',async({page})=>{
    
    await page.getByText('Forgot your password?').click()
})
test.fail('Login should Fail',async({page})=>{
     await page.locator('#txtUsername').fill('Admin')
    await page.locator('#txtPassword').fill('Qedge123!')
    await page.locator('#btnLogin').click()
})
